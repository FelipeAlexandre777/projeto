package sistema_doce_pimenta_;

public class Sistema_Doce_Pimenta_ {

    public static void main(String[] args) {
        
    }
    
}
